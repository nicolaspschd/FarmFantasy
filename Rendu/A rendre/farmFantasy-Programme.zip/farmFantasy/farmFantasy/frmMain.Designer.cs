﻿namespace farmFantasy
{
    partial class frmMain
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.label1 = new System.Windows.Forms.Label();
            this.pbxChamps1 = new System.Windows.Forms.PictureBox();
            this.pbxChamps2 = new System.Windows.Forms.PictureBox();
            this.pbxChamps3 = new System.Windows.Forms.PictureBox();
            this.pbxChamps4 = new System.Windows.Forms.PictureBox();
            this.pbxChamps5 = new System.Windows.Forms.PictureBox();
            this.pbxChamps6 = new System.Windows.Forms.PictureBox();
            this.pbxChamps7 = new System.Windows.Forms.PictureBox();
            this.pbxChamps8 = new System.Windows.Forms.PictureBox();
            this.pbxChamps9 = new System.Windows.Forms.PictureBox();
            this.pbxChamps10 = new System.Windows.Forms.PictureBox();
            this.pbxEntrepot = new System.Windows.Forms.PictureBox();
            this.pbxVache = new System.Windows.Forms.PictureBox();
            this.pbxPoule = new System.Windows.Forms.PictureBox();
            this.pbxCochon = new System.Windows.Forms.PictureBox();
            this.pbxMouton = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.gbxInfo = new System.Windows.Forms.GroupBox();
            this.gbxSemencesPlante = new System.Windows.Forms.GroupBox();
            this.lblMaisEntrepot = new System.Windows.Forms.Label();
            this.rbnMais = new System.Windows.Forms.RadioButton();
            this.lblBleEntrepot = new System.Windows.Forms.Label();
            this.lblPatateEntrepot = new System.Windows.Forms.Label();
            this.rbnNothing = new System.Windows.Forms.RadioButton();
            this.lblCarotteEntrepot = new System.Windows.Forms.Label();
            this.rbnBle = new System.Windows.Forms.RadioButton();
            this.lblColzaEntrepot = new System.Windows.Forms.Label();
            this.rbnPatate = new System.Windows.Forms.RadioButton();
            this.rbnColza = new System.Windows.Forms.RadioButton();
            this.rbnCarotte = new System.Windows.Forms.RadioButton();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.lblArgent = new System.Windows.Forms.Label();
            this.btnMagasin = new System.Windows.Forms.Button();
            this.gbxAnimaux = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblBaconEntrepot = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblOeufEntrepot = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblLaineEntrepot = new System.Windows.Forms.Label();
            this.lblLaitEntrepot = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblNbrCochon = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblNbrVache = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblNbrPoule = new System.Windows.Forms.Label();
            this.lblNbrMouton = new System.Windows.Forms.Label();
            this.btnSauvegarder = new System.Windows.Forms.Button();
            this.lblEntrepot = new System.Windows.Forms.Label();
            this.lblAPropos = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbxChamps1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxChamps2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxChamps3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxChamps4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxChamps5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxChamps6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxChamps7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxChamps8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxChamps9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxChamps10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxEntrepot)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxVache)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPoule)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxCochon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxMouton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.gbxInfo.SuspendLayout();
            this.gbxSemencesPlante.SuspendLayout();
            this.gbxAnimaux.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(101, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(28, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "CHF";
            // 
            // pbxChamps1
            // 
            this.pbxChamps1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbxChamps1.ErrorImage")));
            this.pbxChamps1.Image = ((System.Drawing.Image)(resources.GetObject("pbxChamps1.Image")));
            this.pbxChamps1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbxChamps1.InitialImage")));
            this.pbxChamps1.Location = new System.Drawing.Point(12, 53);
            this.pbxChamps1.Name = "pbxChamps1";
            this.pbxChamps1.Size = new System.Drawing.Size(100, 100);
            this.pbxChamps1.TabIndex = 2;
            this.pbxChamps1.TabStop = false;
            this.pbxChamps1.Click += new System.EventHandler(this.pbxClickChamps_Click);
            // 
            // pbxChamps2
            // 
            this.pbxChamps2.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbxChamps2.ErrorImage")));
            this.pbxChamps2.Image = ((System.Drawing.Image)(resources.GetObject("pbxChamps2.Image")));
            this.pbxChamps2.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbxChamps2.InitialImage")));
            this.pbxChamps2.Location = new System.Drawing.Point(123, 159);
            this.pbxChamps2.Name = "pbxChamps2";
            this.pbxChamps2.Size = new System.Drawing.Size(100, 100);
            this.pbxChamps2.TabIndex = 2;
            this.pbxChamps2.TabStop = false;
            this.pbxChamps2.Click += new System.EventHandler(this.pbxClickChamps_Click);
            // 
            // pbxChamps3
            // 
            this.pbxChamps3.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbxChamps3.ErrorImage")));
            this.pbxChamps3.Image = ((System.Drawing.Image)(resources.GetObject("pbxChamps3.Image")));
            this.pbxChamps3.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbxChamps3.InitialImage")));
            this.pbxChamps3.Location = new System.Drawing.Point(229, 159);
            this.pbxChamps3.Name = "pbxChamps3";
            this.pbxChamps3.Size = new System.Drawing.Size(100, 100);
            this.pbxChamps3.TabIndex = 2;
            this.pbxChamps3.TabStop = false;
            this.pbxChamps3.Click += new System.EventHandler(this.pbxClickChamps_Click);
            // 
            // pbxChamps4
            // 
            this.pbxChamps4.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbxChamps4.ErrorImage")));
            this.pbxChamps4.Image = ((System.Drawing.Image)(resources.GetObject("pbxChamps4.Image")));
            this.pbxChamps4.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbxChamps4.InitialImage")));
            this.pbxChamps4.Location = new System.Drawing.Point(123, 265);
            this.pbxChamps4.Name = "pbxChamps4";
            this.pbxChamps4.Size = new System.Drawing.Size(100, 100);
            this.pbxChamps4.TabIndex = 2;
            this.pbxChamps4.TabStop = false;
            this.pbxChamps4.Click += new System.EventHandler(this.pbxClickChamps_Click);
            // 
            // pbxChamps5
            // 
            this.pbxChamps5.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbxChamps5.ErrorImage")));
            this.pbxChamps5.Image = ((System.Drawing.Image)(resources.GetObject("pbxChamps5.Image")));
            this.pbxChamps5.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbxChamps5.InitialImage")));
            this.pbxChamps5.Location = new System.Drawing.Point(229, 371);
            this.pbxChamps5.Name = "pbxChamps5";
            this.pbxChamps5.Size = new System.Drawing.Size(100, 100);
            this.pbxChamps5.TabIndex = 2;
            this.pbxChamps5.TabStop = false;
            this.pbxChamps5.Click += new System.EventHandler(this.pbxClickChamps_Click);
            // 
            // pbxChamps6
            // 
            this.pbxChamps6.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbxChamps6.ErrorImage")));
            this.pbxChamps6.Image = ((System.Drawing.Image)(resources.GetObject("pbxChamps6.Image")));
            this.pbxChamps6.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbxChamps6.InitialImage")));
            this.pbxChamps6.Location = new System.Drawing.Point(12, 371);
            this.pbxChamps6.Name = "pbxChamps6";
            this.pbxChamps6.Size = new System.Drawing.Size(100, 100);
            this.pbxChamps6.TabIndex = 2;
            this.pbxChamps6.TabStop = false;
            this.pbxChamps6.Click += new System.EventHandler(this.pbxClickChamps_Click);
            // 
            // pbxChamps7
            // 
            this.pbxChamps7.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbxChamps7.ErrorImage")));
            this.pbxChamps7.Image = ((System.Drawing.Image)(resources.GetObject("pbxChamps7.Image")));
            this.pbxChamps7.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbxChamps7.InitialImage")));
            this.pbxChamps7.Location = new System.Drawing.Point(335, 265);
            this.pbxChamps7.Name = "pbxChamps7";
            this.pbxChamps7.Size = new System.Drawing.Size(100, 100);
            this.pbxChamps7.TabIndex = 2;
            this.pbxChamps7.TabStop = false;
            this.pbxChamps7.Click += new System.EventHandler(this.pbxClickChamps_Click);
            // 
            // pbxChamps8
            // 
            this.pbxChamps8.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbxChamps8.ErrorImage")));
            this.pbxChamps8.Image = ((System.Drawing.Image)(resources.GetObject("pbxChamps8.Image")));
            this.pbxChamps8.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbxChamps8.InitialImage")));
            this.pbxChamps8.Location = new System.Drawing.Point(335, 53);
            this.pbxChamps8.Name = "pbxChamps8";
            this.pbxChamps8.Size = new System.Drawing.Size(100, 100);
            this.pbxChamps8.TabIndex = 2;
            this.pbxChamps8.TabStop = false;
            this.pbxChamps8.Click += new System.EventHandler(this.pbxClickChamps_Click);
            // 
            // pbxChamps9
            // 
            this.pbxChamps9.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbxChamps9.ErrorImage")));
            this.pbxChamps9.Image = ((System.Drawing.Image)(resources.GetObject("pbxChamps9.Image")));
            this.pbxChamps9.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbxChamps9.InitialImage")));
            this.pbxChamps9.Location = new System.Drawing.Point(441, 53);
            this.pbxChamps9.Name = "pbxChamps9";
            this.pbxChamps9.Size = new System.Drawing.Size(100, 100);
            this.pbxChamps9.TabIndex = 2;
            this.pbxChamps9.TabStop = false;
            this.pbxChamps9.Click += new System.EventHandler(this.pbxClickChamps_Click);
            // 
            // pbxChamps10
            // 
            this.pbxChamps10.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbxChamps10.ErrorImage")));
            this.pbxChamps10.Image = ((System.Drawing.Image)(resources.GetObject("pbxChamps10.Image")));
            this.pbxChamps10.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbxChamps10.InitialImage")));
            this.pbxChamps10.Location = new System.Drawing.Point(441, 265);
            this.pbxChamps10.Name = "pbxChamps10";
            this.pbxChamps10.Size = new System.Drawing.Size(100, 100);
            this.pbxChamps10.TabIndex = 2;
            this.pbxChamps10.TabStop = false;
            this.pbxChamps10.Click += new System.EventHandler(this.pbxClickChamps_Click);
            // 
            // pbxEntrepot
            // 
            this.pbxEntrepot.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxEntrepot.Image = ((System.Drawing.Image)(resources.GetObject("pbxEntrepot.Image")));
            this.pbxEntrepot.Location = new System.Drawing.Point(12, 159);
            this.pbxEntrepot.Name = "pbxEntrepot";
            this.pbxEntrepot.Size = new System.Drawing.Size(100, 206);
            this.pbxEntrepot.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxEntrepot.TabIndex = 3;
            this.pbxEntrepot.TabStop = false;
            this.pbxEntrepot.Click += new System.EventHandler(this.pbxEntrepot_Click);
            // 
            // pbxVache
            // 
            this.pbxVache.Image = ((System.Drawing.Image)(resources.GetObject("pbxVache.Image")));
            this.pbxVache.Location = new System.Drawing.Point(123, 53);
            this.pbxVache.Name = "pbxVache";
            this.pbxVache.Size = new System.Drawing.Size(206, 100);
            this.pbxVache.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxVache.TabIndex = 4;
            this.pbxVache.TabStop = false;
            // 
            // pbxPoule
            // 
            this.pbxPoule.Image = ((System.Drawing.Image)(resources.GetObject("pbxPoule.Image")));
            this.pbxPoule.Location = new System.Drawing.Point(123, 371);
            this.pbxPoule.Name = "pbxPoule";
            this.pbxPoule.Size = new System.Drawing.Size(100, 100);
            this.pbxPoule.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxPoule.TabIndex = 5;
            this.pbxPoule.TabStop = false;
            // 
            // pbxCochon
            // 
            this.pbxCochon.Image = ((System.Drawing.Image)(resources.GetObject("pbxCochon.Image")));
            this.pbxCochon.Location = new System.Drawing.Point(335, 159);
            this.pbxCochon.Name = "pbxCochon";
            this.pbxCochon.Size = new System.Drawing.Size(206, 100);
            this.pbxCochon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxCochon.TabIndex = 6;
            this.pbxCochon.TabStop = false;
            // 
            // pbxMouton
            // 
            this.pbxMouton.Image = ((System.Drawing.Image)(resources.GetObject("pbxMouton.Image")));
            this.pbxMouton.Location = new System.Drawing.Point(335, 371);
            this.pbxMouton.Name = "pbxMouton";
            this.pbxMouton.Size = new System.Drawing.Size(206, 100);
            this.pbxMouton.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxMouton.TabIndex = 7;
            this.pbxMouton.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(229, 265);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(100, 100);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 8;
            this.pictureBox6.TabStop = false;
            // 
            // gbxInfo
            // 
            this.gbxInfo.BackColor = System.Drawing.Color.Transparent;
            this.gbxInfo.Controls.Add(this.gbxSemencesPlante);
            this.gbxInfo.ForeColor = System.Drawing.Color.White;
            this.gbxInfo.Location = new System.Drawing.Point(547, 53);
            this.gbxInfo.Name = "gbxInfo";
            this.gbxInfo.Size = new System.Drawing.Size(256, 192);
            this.gbxInfo.TabIndex = 2;
            this.gbxInfo.TabStop = false;
            this.gbxInfo.Text = "Semences";
            // 
            // gbxSemencesPlante
            // 
            this.gbxSemencesPlante.BackColor = System.Drawing.Color.Transparent;
            this.gbxSemencesPlante.Controls.Add(this.lblMaisEntrepot);
            this.gbxSemencesPlante.Controls.Add(this.rbnMais);
            this.gbxSemencesPlante.Controls.Add(this.lblBleEntrepot);
            this.gbxSemencesPlante.Controls.Add(this.lblPatateEntrepot);
            this.gbxSemencesPlante.Controls.Add(this.rbnNothing);
            this.gbxSemencesPlante.Controls.Add(this.lblCarotteEntrepot);
            this.gbxSemencesPlante.Controls.Add(this.rbnBle);
            this.gbxSemencesPlante.Controls.Add(this.lblColzaEntrepot);
            this.gbxSemencesPlante.Controls.Add(this.rbnPatate);
            this.gbxSemencesPlante.Controls.Add(this.rbnColza);
            this.gbxSemencesPlante.Controls.Add(this.rbnCarotte);
            this.gbxSemencesPlante.ForeColor = System.Drawing.Color.White;
            this.gbxSemencesPlante.Location = new System.Drawing.Point(6, 16);
            this.gbxSemencesPlante.Name = "gbxSemencesPlante";
            this.gbxSemencesPlante.Size = new System.Drawing.Size(244, 170);
            this.gbxSemencesPlante.TabIndex = 2;
            this.gbxSemencesPlante.TabStop = false;
            this.gbxSemencesPlante.Text = "Planter";
            // 
            // lblMaisEntrepot
            // 
            this.lblMaisEntrepot.AutoSize = true;
            this.lblMaisEntrepot.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaisEntrepot.ForeColor = System.Drawing.Color.White;
            this.lblMaisEntrepot.Location = new System.Drawing.Point(137, 137);
            this.lblMaisEntrepot.Name = "lblMaisEntrepot";
            this.lblMaisEntrepot.Size = new System.Drawing.Size(47, 15);
            this.lblMaisEntrepot.TabIndex = 0;
            this.lblMaisEntrepot.Text = "label6";
            // 
            // rbnMais
            // 
            this.rbnMais.AutoSize = true;
            this.rbnMais.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnMais.ForeColor = System.Drawing.Color.White;
            this.rbnMais.Location = new System.Drawing.Point(53, 135);
            this.rbnMais.Name = "rbnMais";
            this.rbnMais.Size = new System.Drawing.Size(56, 19);
            this.rbnMais.TabIndex = 5;
            this.rbnMais.TabStop = true;
            this.rbnMais.Text = "Maïs";
            this.rbnMais.UseVisualStyleBackColor = true;
            // 
            // lblBleEntrepot
            // 
            this.lblBleEntrepot.AutoSize = true;
            this.lblBleEntrepot.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBleEntrepot.ForeColor = System.Drawing.Color.White;
            this.lblBleEntrepot.Location = new System.Drawing.Point(137, 44);
            this.lblBleEntrepot.Name = "lblBleEntrepot";
            this.lblBleEntrepot.Size = new System.Drawing.Size(47, 15);
            this.lblBleEntrepot.TabIndex = 0;
            this.lblBleEntrepot.Text = "label6";
            // 
            // lblPatateEntrepot
            // 
            this.lblPatateEntrepot.AutoSize = true;
            this.lblPatateEntrepot.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPatateEntrepot.ForeColor = System.Drawing.Color.White;
            this.lblPatateEntrepot.Location = new System.Drawing.Point(137, 113);
            this.lblPatateEntrepot.Name = "lblPatateEntrepot";
            this.lblPatateEntrepot.Size = new System.Drawing.Size(47, 15);
            this.lblPatateEntrepot.TabIndex = 0;
            this.lblPatateEntrepot.Text = "label6";
            // 
            // rbnNothing
            // 
            this.rbnNothing.AutoSize = true;
            this.rbnNothing.Checked = true;
            this.rbnNothing.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnNothing.ForeColor = System.Drawing.Color.White;
            this.rbnNothing.Location = new System.Drawing.Point(53, 19);
            this.rbnNothing.Name = "rbnNothing";
            this.rbnNothing.Size = new System.Drawing.Size(55, 19);
            this.rbnNothing.TabIndex = 0;
            this.rbnNothing.TabStop = true;
            this.rbnNothing.Text = "Rien";
            this.rbnNothing.UseVisualStyleBackColor = true;
            // 
            // lblCarotteEntrepot
            // 
            this.lblCarotteEntrepot.AutoSize = true;
            this.lblCarotteEntrepot.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCarotteEntrepot.ForeColor = System.Drawing.Color.White;
            this.lblCarotteEntrepot.Location = new System.Drawing.Point(137, 90);
            this.lblCarotteEntrepot.Name = "lblCarotteEntrepot";
            this.lblCarotteEntrepot.Size = new System.Drawing.Size(47, 15);
            this.lblCarotteEntrepot.TabIndex = 0;
            this.lblCarotteEntrepot.Text = "label6";
            // 
            // rbnBle
            // 
            this.rbnBle.AutoSize = true;
            this.rbnBle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnBle.ForeColor = System.Drawing.Color.White;
            this.rbnBle.Location = new System.Drawing.Point(53, 42);
            this.rbnBle.Name = "rbnBle";
            this.rbnBle.Size = new System.Drawing.Size(46, 19);
            this.rbnBle.TabIndex = 1;
            this.rbnBle.Text = "Blé";
            this.rbnBle.UseVisualStyleBackColor = true;
            // 
            // lblColzaEntrepot
            // 
            this.lblColzaEntrepot.AutoSize = true;
            this.lblColzaEntrepot.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblColzaEntrepot.ForeColor = System.Drawing.Color.White;
            this.lblColzaEntrepot.Location = new System.Drawing.Point(137, 67);
            this.lblColzaEntrepot.Name = "lblColzaEntrepot";
            this.lblColzaEntrepot.Size = new System.Drawing.Size(47, 15);
            this.lblColzaEntrepot.TabIndex = 0;
            this.lblColzaEntrepot.Text = "label6";
            // 
            // rbnPatate
            // 
            this.rbnPatate.AutoSize = true;
            this.rbnPatate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnPatate.ForeColor = System.Drawing.Color.White;
            this.rbnPatate.Location = new System.Drawing.Point(53, 111);
            this.rbnPatate.Name = "rbnPatate";
            this.rbnPatate.Size = new System.Drawing.Size(66, 19);
            this.rbnPatate.TabIndex = 4;
            this.rbnPatate.Text = "Patate";
            this.rbnPatate.UseVisualStyleBackColor = true;
            // 
            // rbnColza
            // 
            this.rbnColza.AutoSize = true;
            this.rbnColza.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnColza.ForeColor = System.Drawing.Color.White;
            this.rbnColza.Location = new System.Drawing.Point(53, 65);
            this.rbnColza.Name = "rbnColza";
            this.rbnColza.Size = new System.Drawing.Size(61, 19);
            this.rbnColza.TabIndex = 2;
            this.rbnColza.Text = "Colza";
            this.rbnColza.UseVisualStyleBackColor = true;
            // 
            // rbnCarotte
            // 
            this.rbnCarotte.AutoSize = true;
            this.rbnCarotte.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnCarotte.ForeColor = System.Drawing.Color.White;
            this.rbnCarotte.Location = new System.Drawing.Point(53, 88);
            this.rbnCarotte.Name = "rbnCarotte";
            this.rbnCarotte.Size = new System.Drawing.Size(71, 19);
            this.rbnCarotte.TabIndex = 3;
            this.rbnCarotte.Text = "Carotte";
            this.rbnCarotte.UseVisualStyleBackColor = true;
            // 
            // timer
            // 
            this.timer.Interval = 1000;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // lblArgent
            // 
            this.lblArgent.AutoSize = true;
            this.lblArgent.Location = new System.Drawing.Point(135, 9);
            this.lblArgent.Name = "lblArgent";
            this.lblArgent.Size = new System.Drawing.Size(35, 13);
            this.lblArgent.TabIndex = 0;
            this.lblArgent.Text = "label1";
            // 
            // btnMagasin
            // 
            this.btnMagasin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMagasin.Location = new System.Drawing.Point(547, 251);
            this.btnMagasin.Name = "btnMagasin";
            this.btnMagasin.Size = new System.Drawing.Size(256, 29);
            this.btnMagasin.TabIndex = 3;
            this.btnMagasin.Text = "Magasin";
            this.btnMagasin.UseVisualStyleBackColor = true;
            this.btnMagasin.Click += new System.EventHandler(this.btnMagasin_Click);
            // 
            // gbxAnimaux
            // 
            this.gbxAnimaux.BackColor = System.Drawing.Color.Transparent;
            this.gbxAnimaux.Controls.Add(this.groupBox2);
            this.gbxAnimaux.Controls.Add(this.groupBox1);
            this.gbxAnimaux.ForeColor = System.Drawing.Color.White;
            this.gbxAnimaux.Location = new System.Drawing.Point(547, 286);
            this.gbxAnimaux.Name = "gbxAnimaux";
            this.gbxAnimaux.Size = new System.Drawing.Size(256, 185);
            this.gbxAnimaux.TabIndex = 4;
            this.gbxAnimaux.TabStop = false;
            this.gbxAnimaux.Text = "Animaux";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.lblBaconEntrepot);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.lblOeufEntrepot);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.lblLaineEntrepot);
            this.groupBox2.Controls.Add(this.lblLaitEntrepot);
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(126, 19);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(124, 160);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Entrepôt";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(3, 90);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 15);
            this.label9.TabIndex = 13;
            this.label9.Text = "Bacon :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(6, 30);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 15);
            this.label8.TabIndex = 13;
            this.label8.Text = "Oeufs :";
            // 
            // lblBaconEntrepot
            // 
            this.lblBaconEntrepot.AutoSize = true;
            this.lblBaconEntrepot.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBaconEntrepot.ForeColor = System.Drawing.Color.White;
            this.lblBaconEntrepot.Location = new System.Drawing.Point(57, 90);
            this.lblBaconEntrepot.Name = "lblBaconEntrepot";
            this.lblBaconEntrepot.Size = new System.Drawing.Size(47, 15);
            this.lblBaconEntrepot.TabIndex = 13;
            this.lblBaconEntrepot.Text = "label6";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(7, 60);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 15);
            this.label7.TabIndex = 13;
            this.label7.Text = "Laine :";
            // 
            // lblOeufEntrepot
            // 
            this.lblOeufEntrepot.AutoSize = true;
            this.lblOeufEntrepot.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOeufEntrepot.ForeColor = System.Drawing.Color.White;
            this.lblOeufEntrepot.Location = new System.Drawing.Point(57, 30);
            this.lblOeufEntrepot.Name = "lblOeufEntrepot";
            this.lblOeufEntrepot.Size = new System.Drawing.Size(47, 15);
            this.lblOeufEntrepot.TabIndex = 13;
            this.lblOeufEntrepot.Text = "label6";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(19, 120);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 15);
            this.label6.TabIndex = 13;
            this.label6.Text = "Lait :";
            // 
            // lblLaineEntrepot
            // 
            this.lblLaineEntrepot.AutoSize = true;
            this.lblLaineEntrepot.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLaineEntrepot.ForeColor = System.Drawing.Color.White;
            this.lblLaineEntrepot.Location = new System.Drawing.Point(57, 60);
            this.lblLaineEntrepot.Name = "lblLaineEntrepot";
            this.lblLaineEntrepot.Size = new System.Drawing.Size(47, 15);
            this.lblLaineEntrepot.TabIndex = 13;
            this.lblLaineEntrepot.Text = "label6";
            // 
            // lblLaitEntrepot
            // 
            this.lblLaitEntrepot.AutoSize = true;
            this.lblLaitEntrepot.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLaitEntrepot.ForeColor = System.Drawing.Color.White;
            this.lblLaitEntrepot.Location = new System.Drawing.Point(57, 120);
            this.lblLaitEntrepot.Name = "lblLaitEntrepot";
            this.lblLaitEntrepot.Size = new System.Drawing.Size(47, 15);
            this.lblLaitEntrepot.TabIndex = 13;
            this.lblLaitEntrepot.Text = "label6";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblNbrCochon);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.lblNbrVache);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.lblNbrPoule);
            this.groupBox1.Controls.Add(this.lblNbrMouton);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(6, 19);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(119, 160);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Animaux";
            // 
            // lblNbrCochon
            // 
            this.lblNbrCochon.AutoSize = true;
            this.lblNbrCochon.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNbrCochon.ForeColor = System.Drawing.Color.White;
            this.lblNbrCochon.Location = new System.Drawing.Point(62, 90);
            this.lblNbrCochon.Name = "lblNbrCochon";
            this.lblNbrCochon.Size = new System.Drawing.Size(47, 15);
            this.lblNbrCochon.TabIndex = 13;
            this.lblNbrCochon.Text = "label6";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(12, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 15);
            this.label2.TabIndex = 0;
            this.label2.Text = "Poule";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(1, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 15);
            this.label3.TabIndex = 0;
            this.label3.Text = "Mouton";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(10, 120);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 15);
            this.label4.TabIndex = 0;
            this.label4.Text = "Vache";
            // 
            // lblNbrVache
            // 
            this.lblNbrVache.AutoSize = true;
            this.lblNbrVache.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNbrVache.ForeColor = System.Drawing.Color.White;
            this.lblNbrVache.Location = new System.Drawing.Point(62, 120);
            this.lblNbrVache.Name = "lblNbrVache";
            this.lblNbrVache.Size = new System.Drawing.Size(47, 15);
            this.lblNbrVache.TabIndex = 13;
            this.lblNbrVache.Text = "label6";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(1, 90);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 15);
            this.label5.TabIndex = 0;
            this.label5.Text = "Cochon";
            // 
            // lblNbrPoule
            // 
            this.lblNbrPoule.AutoSize = true;
            this.lblNbrPoule.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNbrPoule.ForeColor = System.Drawing.Color.White;
            this.lblNbrPoule.Location = new System.Drawing.Point(62, 30);
            this.lblNbrPoule.Name = "lblNbrPoule";
            this.lblNbrPoule.Size = new System.Drawing.Size(47, 15);
            this.lblNbrPoule.TabIndex = 13;
            this.lblNbrPoule.Text = "label6";
            // 
            // lblNbrMouton
            // 
            this.lblNbrMouton.AutoSize = true;
            this.lblNbrMouton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNbrMouton.ForeColor = System.Drawing.Color.White;
            this.lblNbrMouton.Location = new System.Drawing.Point(62, 60);
            this.lblNbrMouton.Name = "lblNbrMouton";
            this.lblNbrMouton.Size = new System.Drawing.Size(47, 15);
            this.lblNbrMouton.TabIndex = 13;
            this.lblNbrMouton.Text = "label6";
            // 
            // btnSauvegarder
            // 
            this.btnSauvegarder.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSauvegarder.Location = new System.Drawing.Point(229, 4);
            this.btnSauvegarder.Name = "btnSauvegarder";
            this.btnSauvegarder.Size = new System.Drawing.Size(92, 22);
            this.btnSauvegarder.TabIndex = 1;
            this.btnSauvegarder.Text = "Sauvegarder";
            this.btnSauvegarder.UseVisualStyleBackColor = true;
            this.btnSauvegarder.Click += new System.EventHandler(this.btnSauvegarder_Click);
            // 
            // lblEntrepot
            // 
            this.lblEntrepot.AutoSize = true;
            this.lblEntrepot.Location = new System.Drawing.Point(34, 335);
            this.lblEntrepot.Name = "lblEntrepot";
            this.lblEntrepot.Size = new System.Drawing.Size(47, 13);
            this.lblEntrepot.TabIndex = 9;
            this.lblEntrepot.Text = "Entrepôt";
            this.lblEntrepot.Click += new System.EventHandler(this.pbxEntrepot_Click);
            // 
            // lblAPropos
            // 
            this.lblAPropos.AutoSize = true;
            this.lblAPropos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblAPropos.Location = new System.Drawing.Point(9, 9);
            this.lblAPropos.Name = "lblAPropos";
            this.lblAPropos.Size = new System.Drawing.Size(50, 13);
            this.lblAPropos.TabIndex = 10;
            this.lblAPropos.Text = "A Propos";
            this.lblAPropos.Click += new System.EventHandler(this.lblAPropos_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(815, 482);
            this.Controls.Add(this.lblAPropos);
            this.Controls.Add(this.lblEntrepot);
            this.Controls.Add(this.btnSauvegarder);
            this.Controls.Add(this.gbxAnimaux);
            this.Controls.Add(this.btnMagasin);
            this.Controls.Add(this.lblArgent);
            this.Controls.Add(this.gbxInfo);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pbxMouton);
            this.Controls.Add(this.pbxCochon);
            this.Controls.Add(this.pbxPoule);
            this.Controls.Add(this.pbxVache);
            this.Controls.Add(this.pbxEntrepot);
            this.Controls.Add(this.pbxChamps6);
            this.Controls.Add(this.pbxChamps10);
            this.Controls.Add(this.pbxChamps9);
            this.Controls.Add(this.pbxChamps8);
            this.Controls.Add(this.pbxChamps7);
            this.Controls.Add(this.pbxChamps5);
            this.Controls.Add(this.pbxChamps4);
            this.Controls.Add(this.pbxChamps3);
            this.Controls.Add(this.pbxChamps2);
            this.Controls.Add(this.pbxChamps1);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Farm Fantasy";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Load += new System.EventHandler(this.frmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbxChamps1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxChamps2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxChamps3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxChamps4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxChamps5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxChamps6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxChamps7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxChamps8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxChamps9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxChamps10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxEntrepot)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxVache)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPoule)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxCochon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxMouton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.gbxInfo.ResumeLayout(false);
            this.gbxSemencesPlante.ResumeLayout(false);
            this.gbxSemencesPlante.PerformLayout();
            this.gbxAnimaux.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pbxChamps1;
        private System.Windows.Forms.PictureBox pbxChamps2;
        private System.Windows.Forms.PictureBox pbxChamps3;
        private System.Windows.Forms.PictureBox pbxChamps4;
        private System.Windows.Forms.PictureBox pbxChamps5;
        private System.Windows.Forms.PictureBox pbxChamps6;
        private System.Windows.Forms.PictureBox pbxChamps7;
        private System.Windows.Forms.PictureBox pbxChamps8;
        private System.Windows.Forms.PictureBox pbxChamps9;
        private System.Windows.Forms.PictureBox pbxChamps10;
        private System.Windows.Forms.PictureBox pbxEntrepot;
        private System.Windows.Forms.PictureBox pbxVache;
        private System.Windows.Forms.PictureBox pbxPoule;
        private System.Windows.Forms.PictureBox pbxCochon;
        private System.Windows.Forms.PictureBox pbxMouton;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.GroupBox gbxInfo;
        private System.Windows.Forms.RadioButton rbnPatate;
        private System.Windows.Forms.RadioButton rbnCarotte;
        private System.Windows.Forms.RadioButton rbnColza;
        private System.Windows.Forms.RadioButton rbnBle;
        private System.Windows.Forms.RadioButton rbnNothing;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.Button btnMagasin;
        public System.Windows.Forms.Label lblArgent;
        private System.Windows.Forms.GroupBox gbxAnimaux;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox gbxSemencesPlante;
        private System.Windows.Forms.RadioButton rbnMais;
        public System.Windows.Forms.Label lblBleEntrepot;
        public System.Windows.Forms.Label lblPatateEntrepot;
        public System.Windows.Forms.Label lblCarotteEntrepot;
        public System.Windows.Forms.Label lblColzaEntrepot;
        public System.Windows.Forms.Label lblMaisEntrepot;
        private System.Windows.Forms.Label lblNbrCochon;
        private System.Windows.Forms.Label lblNbrVache;
        private System.Windows.Forms.Label lblNbrMouton;
        private System.Windows.Forms.Label lblNbrPoule;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblBaconEntrepot;
        private System.Windows.Forms.Label lblLaitEntrepot;
        private System.Windows.Forms.Label lblLaineEntrepot;
        private System.Windows.Forms.Label lblOeufEntrepot;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnSauvegarder;
        private System.Windows.Forms.Label lblEntrepot;
        private System.Windows.Forms.Label lblAPropos;
    }
}

